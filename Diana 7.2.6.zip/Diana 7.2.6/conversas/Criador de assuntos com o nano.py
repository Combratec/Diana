x=54
import os

while True:
   nano = "nano "+str(x)+".txt"
   os.system(nano)
   x=x+1
